# PrecisionAgriculture
This model will be able to recommend farmers with the crop to plant in an area based on weather and soil content such as ph, temperature, humidity, rainfall and NPK.
[BDS_CDS_3353_GROUP_ONE.docx](https://github.com/AbayoBrian/PrecisionAgriculture/files/15373678/BDS_CDS_3353_GROUP_ONE.docx)
