import warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from ipywidgets import interact
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
data = pd.read_csv(r"C:\GroupOne ML model Deployment\Crop_Recommendation.csv")
data.head()
print("Shape of the dataset:", data.shape)
data.isnull().sum()
# Exploratory data analysis
# Average of differennt variables
print("Average ratio of Nitrogen in Soil:{0: .2f}".format(data["N"].mean()))
# ratio_of_nitrogen = "Ratio of Nitrogen in Soil: {:.2f}".format(data["N"].mean())
print("Average ratio of Phosphorus in Soil:{0: .2f}".format(data["P"].mean()))
print("Average ratio of Potassium in Soil:{0: .2f}".format(data["K"].mean()))
print("Average ratio of Tempreture in Celcius:{0: .2f}".format(data["Temperature"].mean()))
print("Average relative humdity in %:{0: .2f}".format(data["Humidity"].mean()))
print("Average pH value of the Soil:{0: .2f}".format(data["ph"].mean()))
print("Average rainfall in mm:{0: .2f}".format(data["Rainfall"].mean()))


# Analysis on Nitrogen
@interact
def summary(crops=list(data['label'].value_counts().index)):
    x = data[data['label'] == crops]
    print("---------------------------------------------")
    print("Statistics for Nitrogen")
    print("Minimum Nitrogen required:", x['N'].min())
    print("Average Nitrogen required:", x['N'].mean())
    print("Maximum Nitrogen required:", x['N'].max())
    print("---------------------------------------------")

    # Analysis on Phosphorus
    @interact
    def summary(crops=list(data['label'].value_counts().index)):
        x = data[data['label'] == crops]
        print("---------------------------------------------")
        print("Statistics for Phosphorus")
        print("Minimum Phosphorus required:", x['P'].min())
        print("Average Phosphorus required:", x['P'].mean())
        print("Maximum Phosphorus required:", x['P'].max())
        print("---------------------------------------------")

    # Analysis on Potassium
    @interact
    def summary(crops=list(data['label'].value_counts().index)):
        x = data[data['label'] == crops]
        print("---------------------------------------------")
        print("Statistics for Potassium")
        print("Minimum Potassium required:", x['K'].min())
        print("Average Potassium required:", x['K'].mean())
        print("Maximum Potassium required:", x['K'].max())
        print("---------------------------------------------")

    # Analysis on Tempreture
    @interact
    def summary(crops=list(data['label'].value_counts().index)):
        x = data[data['label'] == crops]
        print("----------------------------------------")
        print("Statistics for Tempreture")
        print("Minimum Temperature required: {:.2f}".format(x['Temperature'].min()))
        print("Average Temperature required: {:.2f}".format(x['Temperature'].mean()))
        print("Maximum Temperature required: {:.2f}".format(x['Temperature'].max()))
        print("----------------------------------------")


# Analysis on Humidity
@interact
def summary(crops=list(data['label'].value_counts().index)):
    x = data[data['label'] == crops]
    print("---------------------------------------------")
    print("Statistics for Humidity")
    print("Minimum Humidity required: {:.2f}".format(x['Humidity'].min()))
    print("Average Humidity required: {:.2f}".format(x['Humidity'].mean()))
    print("Maximum Humidity required: {:.2f}".format(x['Humidity'].max()))
    print("---------------------------------------------")


# Analysis on ph value
@interact
def summary(crops=list(data['label'].value_counts().index)):
    x = data[data['label'] == crops]
    print("---------------------------------------------")
    print("Statistics for pH")
    print("Minimum pH required: {:.2f}".format(x['ph'].min()))
    print("Average pH required: {:.2f}".format(x['ph'].mean()))
    print("Maximum pH required: {:.2f}".format(x['ph'].max()))
    print("---------------------------------------------")


# Analysis on rainfall
@interact
def summary(crops=list(data['label'].value_counts().index)):
    x = data[data['label'] == crops]
    print("---------------------------------------------")
    print("Statistics for Rainfall")
    print("Minimum Rainfall required: {:.2f}".format(x['Rainfall'].min()))
    print("Average Rainfall required: {:.2f}".format(x['Rainfall'].mean()))
    print("Maximum Rainfall required: {:.2f}".format(x['Rainfall'].max()))
    print("---------------------------------------------")


# Average Requirement for each crop

@interact
def compare(conditions=['N', 'P', 'K', 'Temperature', 'ph', 'Humidity', 'Rainfall']):
    print("Crops which require greater than average", conditions, '\n')
    print("-------------------------------------")
    print(data[data[conditions] > data[conditions].mean()]['label'].unique())
    print("-------------------------------------")
    print("Crops which require less than average", conditions, '\n')
    print("-------------------------------------")
    print(data[data[conditions] <= data[conditions].mean()]['label'].unique())
    print("-------------------------------------")


# Data visualization
# Nitrogen Distribution graph
sns.histplot(data['N'], color='lightgrey')
plt.show()
# Phosphorus disribution graph
sns.histplot(data['P'], color='lightgrey')
plt.show()
# Potassium Distribution graph
sns.histplot(data['K'], color='lightgrey')
plt.show()
# Tempreture distribution graph
sns.histplot(data['Temperature'], color='lightgrey')
plt.show()
# ph value
sns.histplot(data['ph'], color='lightgrey')
plt.show()
# Rainfall distribution graph
sns.histplot(data['Rainfall'], color='lightgrey')
plt.show()
# Humidity distribution graph
sns.histplot(data['N'], color='lightgrey')
plt.show()

# Subplots showing distribution
# Create subplots with 2 rows and 4 columns
fig, axes = plt.subplots(2, 4, figsize=(16, 8))
# Define the data columns and colors
columns = ['N', 'P', 'K', 'Temperature', 'Rainfall', 'Humidity', 'ph']  # or columns = list(data.keys())
colors = ['lightgrey', 'lightblue', 'darkblue', 'black', 'grey', 'lightgreen', 'darkgreen']
# Loop through the subplots and create the distribution plots
for i, col in enumerate(columns):
    row = i // 4
    col_num = i % 4

    sns.distplot(data[col], color=colors[i], ax=axes[row, col_num])
    axes[row, col_num].set_xlabel(f'Ratio of {col}', fontsize=12)
    axes[row, col_num].grid()

# Statistical facts about crop requirements
print("Some Interesting Patterns")
print("--------------------------")
print("Crops which requires very High Ratio of Nirtogen Content in Soil:", data[data['N'] > 120]['label'].unique())
print("--------------------------")
print("Crops which requires very High Ratio of Phosphorous Content in Soil:", data[data['P'] > 100]['label'].unique())
print("--------------------------")
print("Crops which requires very High Ratio of Potassium Content in Soil:", data[data['K'] > 200]['label'].unique())
print("--------------------------")
print("Crops which requires very High Rainfall:", data[data['Rainfall'] > 200]['label'].unique())
print("--------------------------")
print("Crops which requires very Low Temperature:", data[data['Temperature'] > 10]['label'].unique())
print("--------------------------")
print("Crops which requires very High Temperature:", data[data['Temperature'] > 40]['label'].unique())
print("--------------------------")
print("Crops which requires very Low Humidty:", data[data['Humidity'] > 20]['label'].unique())
print("--------------------------")
print("Crops which requires very Low pH:", data[data['ph'] < 4]['label'].unique())
print("--------------------------")
print("Cr0ps which requires very Low pH:", data[data['ph'] > 9]['label'].unique())
print("--------------------------")
# Explanation:

# data['N'] > 120: This part creates a boolean mask by checking if the values in the 'N' column of the data DataFrame are greater than 120. It returns a boolean Series where each element is True if the condition is met and False otherwise.

# data[data['N'] > 120]: This part filters the rows of the DataFrame where the condition data['N'] > 120 is True. It selects only those rows where the Nitrogen content is greater than 120.

# ['label']: This part selects the 'label' column from the filtered DataFrame.

# .unique(): This method returns an array of unique values from the 'label' column.

# Finally, the print statement outputs the message along with the unique labels of crops that require a very high ratio of Nitrogen content in the soil.


# Feature Selection
from sklearn.cluster import KMeans

# removing the labels column
x = data.drop(['label'], axis=1)
# selecting all the values of the data
x = x.values
# checking the shape
print(x.shape)

# Determining the optimum number of clusters in the dataset
# Elbow method
plt.rcParams['figure.figsize'] = (10, 4)
wcss = []
for i in range(1, 11):
    km = KMeans(n_clusters=i, init='k-means++', max_iter=300, n_init=10, random_state=0)
    km.fit(x)
    wcss.append(km.inertia_)

# Lets plot the results
plt.plot(range(1, 11), wcss)
plt.title('The Elbow Method', fontsize=20)
plt.xlabel('No. of Clusters')
plt.ylabel('wcss')
plt.show()
km = KMeans(n_clusters=4, init='k-means++', max_iter=300, n_init=10, random_state=0)
y_means = km.fit_predict(x)
# Lets find out the Results
a = data['label']
y_means = pd.DataFrame(y_means)
z = pd.concat([y_means, a], axis=1)
z = z.rename(columns={0: 'cluster'})
# Lets check the Clusters of each Crops
print("Lets check the Results After Applying the K Means Clustering Analysis \n")
print("Crops in First cluster:", z[z['cluster'] == 0]['label'].unique())
print("----------------------------------------------------------------")
print("Crops in Second cluster:", z[z['cluster'] == 1]['label'].unique())
print("----------------------------------------------------------------")
print("Crops in Third cluster:", z[z['cluster'] == 2]['label'].unique())
print("----------------------------------------------------------------")
print("Crops in Forth cluster:", z[z['cluster'] == 3]['label'].unique())

# Spliting the dataset foe predictive modelling
y = data['label']
x = data.drop(['label'], axis=1)
print("Shape of x:", x.shape)
print("shape of y:", y.shape)

from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)
print("The Shape of x train:", x_train.shape)
print("The Shape of x test:", x_test.shape)
print("The Shape of y train:", y_train.shape)
print("The Shape of y test:", x_test.shape)

# Define hyperparameter grids for each algorithm
param_grid_rf = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

param_grid_svc = {
    'C': [0.1, 1, 10],
    'gamma': [0.001, 0.01, 0.1, 1],
    'kernel': ['rbf', 'linear']
}

param_grid_lr = {
    'C': [0.001, 0.01, 0.1, 1, 10],
    'penalty': ['l1', 'l2'],
    'solver': ['liblinear']
}
# Instantiate classifiers
rf = RandomForestClassifier()
svc = SVC()
lr = LogisticRegression()

# Perform grid search for each algorithm
grid_search_rf = GridSearchCV(rf, param_grid_rf, cv=5, n_jobs=-1)
grid_search_svc = GridSearchCV(svc, param_grid_svc, cv=5, n_jobs=-1)
grid_search_lr = GridSearchCV(lr, param_grid_lr, cv=5, n_jobs=-1)

# Fit grid search models
grid_search_rf.fit(x_train, y_train)
grid_search_svc.fit(x_train, y_train)
grid_search_lr.fit(x_train, y_train)

# Get best hyperparameters and models
best_params_rf = grid_search_rf.best_params_
best_model_rf = grid_search_rf.best_estimator_

best_params_svc = grid_search_svc.best_params_
best_model_svc = grid_search_svc.best_estimator_

best_params_lr = grid_search_lr.best_params_
best_model_lr = grid_search_lr.best_estimator_

# Evaluate performance on test set
test_accuracy_rf = best_model_rf.score(x_test, y_test)
test_accuracy_svc = best_model_svc.score(x_test, y_test)
test_accuracy_lr = best_model_lr.score(x_test, y_test)

# Compare performance of models
print("Random Forest Test Accuracy:", test_accuracy_rf)
print("SVM Test Accuracy:", test_accuracy_svc)
print("Logistic Regression Test Accuracy:", test_accuracy_lr)

# Select the best model
best_accuracy = max(test_accuracy_rf, test_accuracy_svc, test_accuracy_lr)
best_model = None

if best_accuracy == test_accuracy_rf:
    best_model = best_model_rf
    best_model_name = "Random Forest"
elif best_accuracy == test_accuracy_svc:
    best_model = best_model_svc
    best_model_name = "SVM"
else:
    best_model = best_model_lr
    best_model_name = "Logistic Regression"

print("Best Model:", best_model_name)

from sklearn.linear_model import LogisticRegression

model = LogisticRegression()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)

# Performance evaluation
from sklearn.metrics import confusion_matrix

# Lets print the Confusion matrix first
plt.rcParams['figure.figsize'] = (10, 10)
cm = confusion_matrix(y_test, y_pred)

# Classification report
from sklearn.metrics import classification_report

cr = classification_report(y_test, y_pred)
print(cr)

best_model_rf = RandomForestClassifier(n_estimators=best_params_rf['n_estimators'],
                                       max_depth=best_params_rf['max_depth'],
                                       min_samples_split=best_params_rf['min_samples_split'],
                                       min_samples_leaf=best_params_rf['min_samples_leaf'])

#Model fit in
best_model_rf.fit(x_train, y_train)

#Performance Evaluation
test_accuracy_rf = best_model_rf.score(x_test, y_test)
print("Random Forest Test Accuracy:", test_accuracy_rf)

#Model testing
prediction = best_model_rf.predict((np.array([[90,
                                       40,
                                       40,
                                       20,
                                       80,
                                       7,
                                       200]])))
print("The Suggested Crop for Given Climatic Condition is :", prediction)

# Saving the model
import pickle
pickle.dump(best_model_rf, open('model_versn.pkl', 'wb'))
